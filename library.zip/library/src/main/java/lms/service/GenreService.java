package lms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lms.entity.Genre;
import lms.repository.GenreRepository;


@Service
public class GenreService {
	
	@Autowired
	private GenreRepository genreRepository;

	public List<Genre> getAllgenre() 
	{
		List<Genre> genres=new ArrayList<>();
		genreRepository.findAll()
		.forEach(genres::add);
		return genres;
		
	}

	public Genre getGenre(String id) 
	{
		return genreRepository.findOne(id);
	}

	public void addGenre(Genre genre)
	{
		genreRepository.save(genre);
	}

	public void updateGenre(String id, Genre genre) 
	{
		genreRepository.save(genre);
	}

	public void deleteGenre(String id)
	{
		genreRepository.delete(id);
	}
	
}
