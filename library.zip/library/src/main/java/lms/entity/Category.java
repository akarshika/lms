package lms.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="CATEGORY")
public class Category {
	
	@Id
	@Column(nullable=false)
	private UUID id;
	
	@Column(nullable=false)
	private String type;
	
	public Category()
	{
		
	}
	
	public Category(UUID id, String type) {
		super();
		this.id = id;
		this.type = type;
	}


	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
