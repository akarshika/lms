package lms.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="MEMBER")
public class Member {
	
	@Id
	private UUID id;
	private String firstname;
	private String lastname;
	private Date DOB;
	private String email;
	private String address;
	
	public Member()
	{
		
	}
	
	public Member(UUID id, String firstname, String lastname, Date dOB, String email, String address) 
	{
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		DOB = dOB;
		this.email = email;
		this.address = address;
	}
	
	public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
