package lms.resource;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lms.category.Category;
import lms.genre.Genre;

@Entity
public class Resource {
	
	@Id
	@Column(nullable=false)
	private String id;
	
	@Column(nullable=false)
	private String name;
	
	
	private String author_name;
	private int quantity;
	private int year_of_publication;
	
	@ManyToOne
	private Category category;
	
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	@ManyToOne
	private Genre genre;
	

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	public Resource()
	{
		
	}
	
	public Resource(String id, String name, String author_name, int quantity, int year_of_publication, String categoryId, String genreId) {
		super();
		this.id = id;
		this.name = name;
		this.author_name = author_name;
		this.quantity = quantity;
		this.year_of_publication = year_of_publication;
		this.category=new Category(categoryId, "");
	
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor_name() {
		return author_name;
	}

	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getYear_of_publication() {
		return year_of_publication;
	}

	public void setYear_of_publication(int year_of_publication) {
		this.year_of_publication = year_of_publication;
	}
	
}
