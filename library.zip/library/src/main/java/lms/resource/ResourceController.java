package lms.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lms.category.Category;

@RestController
public class ResourceController {
	
	@Autowired
	private ResourceService resourceService;
	
	@RequestMapping("category/{categoryId}/resource")
	public List<Resource> getAllresourcesById(@PathVariable String categoryId)
	{
		return resourceService.getAllresourcesById(categoryId);
	}
	
	
	
	@RequestMapping("category/{categoryId}/resource/{id}")
	public Resource getResource(@PathVariable String id)
	{
		return resourceService.getResource(id);
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="category/{categoryId}/resource")
	public void addResource(@RequestBody Resource resource, @PathVariable String categoryId)
	{
		resource.setCategory(new Category(categoryId,""));
		resourceService.addResource(resource);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="category/{categoryId}/resource/{id}")
	public void updateResource(@PathVariable String id, @RequestBody Resource resource, @PathVariable String categoryId)
	{
		resource.setCategory(new Category(categoryId,""));
		resourceService.updateResource(resource);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="category/{categoryId}/resource/{id}")
	public void deleteResource(@PathVariable String id)
	{
		resourceService.deleteResource(id);
	}

}
