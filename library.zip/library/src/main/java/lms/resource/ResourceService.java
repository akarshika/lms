package lms.resource;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ResourceService {

	@Autowired
	private ResourceRepository resourceRepository;

	public List<Resource> getAllresourcesById(String categoryId)
	{
		List<Resource> resources=new ArrayList<>();
		resourceRepository.findByCategoryId(categoryId)
		.forEach(resources::add);
		return resources;
	}
	
	

	public Resource getResource(String id) 
	{
		return resourceRepository.findOne(id);
	}
	

	public void addResource(Resource resource)
	{
		resourceRepository.save(resource);
	}

	public void updateResource(Resource resource)
	{
		resourceRepository.save(resource);
	}

	public void deleteResource(String id) 
	{
		resourceRepository.delete(id);
	}


}
