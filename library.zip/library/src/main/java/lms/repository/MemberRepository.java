package lms.repository;

import org.springframework.data.repository.CrudRepository;

import lms.entity.Member;

public interface MemberRepository extends CrudRepository<Member, String> {

}
