package lms.repository;

import org.springframework.data.repository.CrudRepository;

import lms.entity.Category;

public interface CategoryRepository extends CrudRepository<Category, String> {

}
