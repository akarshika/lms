package lms.repository;

import org.springframework.data.repository.CrudRepository;

import lms.entity.Genre;

public interface GenreRepository extends CrudRepository<Genre, String> {

}
