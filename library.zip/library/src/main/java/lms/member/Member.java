package lms.member;

public class Member {

}
