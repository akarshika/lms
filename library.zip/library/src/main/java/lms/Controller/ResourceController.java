package lms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lms.entity.Category;
import lms.entity.Resource;
import lms.service.ResourceService;

@RestController
public class ResourceController {
	
	@Autowired
	private ResourceService resourceService;
	
	@RequestMapping("/category/{categoryType}/resource")
	public List<Resource> getAllresourcesById(@PathVariable String categoryType)
	{
		return resourceService.getAllresourcesById(categoryType);
	}
	
	@RequestMapping("/genre/{genreType}/resource")
	public List<Resource> getAllgenresById(@PathVariable String genreType)
	{
		return resourceService.getAllgenreById(genreType);
	}
	
	
	@RequestMapping("/category/{categoryType}/resource/{id}")
	public Resource getResource(@PathVariable String id)
	{
		return resourceService.getResource(id);
	}
	
	@RequestMapping("/genre/{genreType}/resource/{id}")
	public Resource getGenre(@PathVariable String id)
	{
		return resourceService.getGenre(id);
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="/category/{categoryType}/resource")
	public void addResource(@RequestBody Resource resource, @PathVariable String categoryType)
	{
		resource.setCategory(new Category(null,categoryType));
		resourceService.addResource(resource);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/category/{categoryType}/resource/{id}")
	public void updateResource(@PathVariable String id, @RequestBody Resource resource, @PathVariable String categoryType)
	{
		resource.setCategory(new Category(null, categoryType));
		resourceService.updateResource(resource);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/category/{categoryType}/resource/{id}")
	public void deleteResource(@PathVariable String id)
	{
		resourceService.deleteResource(id);
	}

}
