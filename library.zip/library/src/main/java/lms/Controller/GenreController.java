package lms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lms.entity.Genre;
import lms.service.GenreService;



@RestController
public class GenreController {
	
	@Autowired
	private GenreService genreService;
	
	@RequestMapping("/genre")
	public List<Genre> getAllgenre()
	{
		return genreService.getAllgenre();
	}
	
	@RequestMapping("/genre/{id}")
	public Genre getGenre(@PathVariable String id)
	{
		return genreService.getGenre(id);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/genre")
	public void addGenre(@RequestBody Genre genre)
	{
	     genreService.addGenre(genre);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/genre/{id}")
	public void updateGenre(@PathVariable String id, @RequestBody Genre genre)
	{
		genreService.updateGenre(id, genre);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/genre/{id}")
	public void deleteGenre(@PathVariable String id)
	{
		genreService.deleteGenre(id);
	}


}
